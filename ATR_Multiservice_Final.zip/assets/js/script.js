function toggleDarkMode() {
  document.body.classList.toggle('dark-mode');
}

function toggleLanguage() {
  alert('Language switch placeholder (IT/EN)');
}
